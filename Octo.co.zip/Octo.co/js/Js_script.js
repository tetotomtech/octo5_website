/**
 * Octo5 Property Development — Main JavaScript
 * Interactions, accessibility, and performance enhancements.
 */

(function () {
  'use strict';

  /* ============================================================
     0. UTILITIES & CONFIG
     ============================================================ */

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function safeQuery(selector) {
    return document.querySelector(selector);
  }

  function safeQueryAll(selector) {
    return document.querySelectorAll(selector);
  }

  /* ============================================================
     1. MOBILE NAVIGATION
     ============================================================ */

  const navToggle = safeQuery('#nav-toggle');
  const primaryNav = safeQuery('#primary-navigation');
  const siteHeader = safeQuery('#site-header');
  const navLinks = safeQueryAll('.nav-link');

  function closeMobileMenu(returnFocus) {
    if (!primaryNav || !navToggle) return;

    primaryNav.classList.remove('is-open');
    if (siteHeader) siteHeader.classList.remove('nav-is-open');

    navToggle.setAttribute('aria-expanded', 'false');
    const currentLabel = navToggle.getAttribute('aria-label') || '';
    if (currentLabel.toLowerCase().includes('close')) {
      navToggle.setAttribute('aria-label', 'Open menu');
    }

    document.body.classList.remove('menu-open');

    if (returnFocus) {
      navToggle.focus();
    }
  }

  function openMobileMenu() {
    if (!primaryNav || !navToggle) return;

    primaryNav.classList.add('is-open');
    if (siteHeader) siteHeader.classList.add('nav-is-open');

    navToggle.setAttribute('aria-expanded', 'true');
    const currentLabel = navToggle.getAttribute('aria-label') || '';
    if (currentLabel.toLowerCase().includes('open')) {
      navToggle.setAttribute('aria-label', 'Close menu');
    }

    document.body.classList.add('menu-open');
  }

  function toggleMobileMenu() {
    if (!primaryNav || !navToggle) return;

    const isOpen = primaryNav.classList.contains('is-open');
    if (isOpen) {
      closeMobileMenu(true);
    } else {
      openMobileMenu();
    }
  }

  if (navToggle && primaryNav) {
    navToggle.addEventListener('click', toggleMobileMenu);

    // Close when a nav link is clicked
    navLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        closeMobileMenu(false);
      });
    });

    // Close on Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && primaryNav.classList.contains('is-open')) {
        closeMobileMenu(true);
      }
    });

    // Close when clicking outside
    document.addEventListener('click', function (e) {
      if (!primaryNav.classList.contains('is-open')) return;
      if (!primaryNav.contains(e.target) && !navToggle.contains(e.target)) {
        closeMobileMenu(false);
      }
    });
  }

  /* ============================================================
     2. SMOOTH SCROLLING (internal anchors)
     ============================================================ */

  const headerOffset = siteHeader ? siteHeader.offsetHeight : 0;

  function scrollToTarget(target, focusTarget) {
    if (!target) return;

    const element = typeof target === 'string' ? safeQuery(target) : target;
    if (!element) return;

    const top = element.getBoundingClientRect().top + window.pageYOffset - headerOffset;

    if (prefersReducedMotion) {
      window.scrollTo(0, top);
    } else {
      window.scrollTo({
        top: top,
        behavior: 'smooth'
      });
    }

    if (focusTarget) {
      element.focus({ preventScroll: true });
      if (document.activeElement !== element) {
        element.setAttribute('tabindex', '-1');
        element.focus({ preventScroll: true });
      }
    }
  }

  document.addEventListener('click', function (e) {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href') || '';

    // Skip external, mailto, tel links
    if (
      href.startsWith('mailto:') ||
      href.startsWith('tel:') ||
      href.startsWith('https://') ||
      href.startsWith('http://')
    ) {
      return;
    }

    // Handle internal anchors
    if (href.startsWith('#') && href.length > 1) {
      e.preventDefault();
      scrollToTarget(href, false);
    }
  });

  /* ============================================================
     3. ACTIVE NAVIGATION (IntersectionObserver)
     ============================================================ */

  const sectionIds = ['home', 'about', 'projects', 'services', 'leadership', 'contact'];
  const navLinkMap = {};

  navLinks.forEach(function (link) {
    const href = link.getAttribute('href') || '';
    if (href.startsWith('#')) {
      const id = href.slice(1);
      if (!navLinkMap[id]) navLinkMap[id] = [];
      navLinkMap[id].push(link);
    }
  });

  function setActiveNav(id) {
    navLinks.forEach(function (link) {
      link.classList.remove('active');
    });

    if (navLinkMap[id]) {
      navLinkMap[id].forEach(function (link) {
        link.classList.add('active');
      });
    }
  }

  const navObserverOptions = {
    root: null,
    rootMargin: '-40% 0px -55% 0px',
    threshold: 0
  };

  if ('IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          setActiveNav(entry.target.id);
        }
      });
    }, navObserverOptions);

    sectionIds.forEach(function (id) {
      const section = safeQuery('#' + id);
      if (section) navObserver.observe(section);
    });
  }

  /* ============================================================
     4. HEADER SCROLL STATE
     ============================================================ */

  let scrollStateTicking = false;

  function updateHeaderScrollState() {
    if (!siteHeader) return;

    const scrollY = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollY > 10) {
      siteHeader.classList.add('scrolled');
    } else {
      siteHeader.classList.remove('scrolled');
    }

    scrollStateTicking = false;
  }

  function onScrollHeader() {
    if (!scrollStateTicking) {
      window.requestAnimationFrame(updateHeaderScrollState);
      scrollStateTicking = true;
    }
  }

  window.addEventListener('scroll', onScrollHeader, { passive: true });
  updateHeaderScrollState(); // Initial check

  /* ============================================================
     5. HERO VIDEO
     ============================================================ */

  const heroVideo = safeQuery('.hero-video');

  if (heroVideo) {
    heroVideo.muted = true;
    heroVideo.setAttribute('muted', '');
    heroVideo.setAttribute('playsinline', '');

    if (!prefersReducedMotion) {
      const playPromise = heroVideo.play();
      if (playPromise !== undefined && typeof playPromise.then === 'function') {
        playPromise.catch(function () {
          // Autoplay blocked or failed — page continues normally
        });
      }
    }
  }

  /* ============================================================
     6. HERO SCROLL INDICATOR
     ============================================================ */

  const heroScrollIndicator = safeQuery('.hero-scroll-indicator');

  if (heroScrollIndicator) {
    heroScrollIndicator.addEventListener('click', function () {
      const nextSection = safeQuery('#about') ||
        (siteHeader && siteHeader.nextElementSibling) ||
        document.querySelector('section:nth-of-type(2)');

      if (nextSection) {
        scrollToTarget(nextSection, false);
      }
    });

    heroScrollIndicator.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        heroScrollIndicator.click();
      }
    });
  }

  /* ============================================================
     7. SCROLL REVEAL ANIMATIONS (IntersectionObserver)
     ============================================================ */

  const revealSelectors = [
    '.section-heading',
    '.project-card',
    '.value-card',
    '.service-item',
    '.process-item',
    '.leadership-content',
    '.leadership-image-wrap',
    '.trust-point'
  ];

  if (!prefersReducedMotion && 'IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      rootMargin: '0px 0px -50px 0px',
      threshold: 0.1
    });

    revealSelectors.forEach(function (selector) {
      const elements = safeQueryAll(selector);
      elements.forEach(function (el) {
        revealObserver.observe(el);
      });
    });
  } else {
    // If reduced motion or no IO, make everything visible immediately
    revealSelectors.forEach(function (selector) {
      const elements = safeQueryAll(selector);
      elements.forEach(function (el) {
        el.classList.add('is-visible');
      });
    });
  }

  /* ============================================================
     8. COUNTER ANIMATION
     ============================================================ */

  const counterElements = safeQueryAll('[data-counter]');

  function animateCounter(el, target, duration) {
    const startTime = performance.now();
    const startValue = 0;

    function step(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out quad
      const ease = 1 - (1 - progress) * (1 - progress);
      const current = Math.floor(startValue + (target - startValue) * ease);

      el.textContent = String(current);

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        el.textContent = String(target);
      }
    }

    requestAnimationFrame(step);
  }

  if (counterElements.length > 0 && !prefersReducedMotion && 'IntersectionObserver' in window) {
    const counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const el = entry.target;
          const raw = el.getAttribute('data-counter') || '';
          const target = parseFloat(raw);

          if (!isNaN(target) && isFinite(target)) {
            animateCounter(el, target, 1500);
          }
          // If it's ∞ or non-numeric, leave it as-is

          counterObserver.unobserve(el);
        }
      });
    }, {
      root: null,
      threshold: 0.5
    });

    counterElements.forEach(function (el) {
      counterObserver.observe(el);
    });
  } else if (counterElements.length > 0 && prefersReducedMotion) {
    // Show final values immediately
    counterElements.forEach(function (el) {
      const raw = el.getAttribute('data-counter') || '';
      const target = parseFloat(raw);
      if (!isNaN(target) && isFinite(target)) {
        el.textContent = String(target);
      }
    });
  }

  /* ============================================================
     9. PROJECT INTERACTIONS
     ============================================================ */

  // CSS handles hover effects. JavaScript only ensures links work.
  const projectCards = safeQueryAll('.project-card');

  projectCards.forEach(function (card) {
    const link = card.querySelector('a');
    if (!link) return;

    card.addEventListener('click', function (e) {
      // If the click target is not the link itself, let the link handle it
      // unless the user clicked an interactive child
      if (e.target.closest('a')) return;
      // Otherwise, normal card behavior; CSS handles visuals
    });
  });

  /* ============================================================
     10. SERVICE INTERACTIONS
     ============================================================ */

  // CSS handles hover states. No extra JS needed unless accordion
  // functionality exists in HTML (it doesn't per instructions).

  /* ============================================================
     11. BACK TO TOP
     ============================================================ */

  const backToTop = safeQuery('#back-to-top');

  function updateBackToTop() {
    if (!backToTop) return;

    const scrollY = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollY > 400) {
      backToTop.classList.add('is-visible');
    } else {
      backToTop.classList.remove('is-visible');
    }
  }

  let backToTopTicking = false;

  function onScrollBackToTop() {
    if (!backToTopTicking) {
      window.requestAnimationFrame(function () {
        updateBackToTop();
        backToTopTicking = false;
      });
      backToTopTicking = true;
    }
  }

  if (backToTop) {
    backToTop.addEventListener('click', function (e) {
      e.preventDefault();
      if (prefersReducedMotion) {
        window.scrollTo(0, 0);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });

    window.addEventListener('scroll', onScrollBackToTop, { passive: true });
    updateBackToTop();
  }

  /* ============================================================
     12. CURRENT YEAR
     ============================================================ */

  const currentYearEl = safeQuery('#current-year');

  if (currentYearEl) {
    currentYearEl.textContent = String(new Date().getFullYear());
  }

  /* ============================================================
     13. ACCESSIBILITY — Focus management helpers
     ============================================================ */

  // Skip-link or focusable target handling for smooth-scroll destinations
  document.querySelectorAll('section[id]').forEach(function (section) {
    if (!section.hasAttribute('tabindex')) {
      section.setAttribute('tabindex', '-1');
    }
  });

})();
